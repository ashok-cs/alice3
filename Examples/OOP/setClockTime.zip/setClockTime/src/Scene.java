// <editor-fold defaultstate="collapsed" desc="imports">

import org.lgna.story.*;
import org.lgna.story.event.SceneActivationEvent;
import org.lgna.story.SRoom.FloorAppearance;
import org.lgna.story.SRoom.WallAppearance;
import org.lgna.story.SGround.SurfaceAppearance;
import javax.swing.JOptionPane;
// </editor-fold>

class Scene extends SScene {

    /* Construct new Scene */
    public Scene() {
        super();
    }

    /* Event listeners */
    private void initializeEventListeners() {
        this.addSceneActivationListener((SceneActivationEvent event) -> {
            this.myFirstMethod();
        });
    }

    /* Procedures and functions for this scene */
    public void myFirstMethod() {
        String time=JOptionPane.showInputDialog(null,"Enter hour as integer");
        int hour=Integer.parseInt(time);
        this.pocketWatch.getHour().roll(RollDirection.LEFT, hour/12.0);
    }
    /* End procedures and functions for this scene */

    // <editor-fold defaultstate="collapsed" desc="/* Scene fields  */">
    private final SRoom room = new SRoom();
    private final SGround ground = new SGround();
    private final SCamera camera = new SCamera();
    private final PocketWatch pocketWatch = new PocketWatch();
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="/* Scene setup  */">
    private void performCustomSetup() {
//Make adjustments to the starting scene, in a way not available in the Scene editor
    }

    private void performGeneratedSetUp() {
//DO NOT EDIT
//This code is automatically generated.  Any work you perform in this method will be overwritten.
//DO NOT EDIT
        this.setAtmosphereColor(new Color(0.5, 0.5, 1.0));
        this.setFromAboveLightColor(Color.WHITE);
        this.setFromBelowLightColor(Color.BLACK);
        this.setFogDensity(0.0);
        this.setName("myScene");
        this.room.setFloorPaint(FloorAppearance.REDWOOD);
        this.room.setWallPaint(WallAppearance.YELLOW);
        this.room.setCeilingPaint(Color.WHITE);
        this.room.setOpacity(1.0);
        this.room.setName("room");
        this.room.setVehicle(this);
        this.ground.setPaint(SurfaceAppearance.GRASS);
        this.ground.setOpacity(1.0);
        this.ground.setName("ground");
        this.ground.setVehicle(this);
        this.camera.setName("camera");
        this.camera.setVehicle(this);
        this.camera.setOrientationRelativeToVehicle(new Orientation(0.0, 0.995185, 0.0980144, 6.12323E-17));
        this.camera.setPositionRelativeToVehicle(new Position(9.49E-16, 2.54, -7.65));
        this.pocketWatch.setPaint(Color.WHITE);
        this.pocketWatch.setOpacity(1.0);
        this.pocketWatch.setName("pocketWatch");
        this.pocketWatch.setVehicle(this);
        this.pocketWatch.setOrientationRelativeToVehicle(new Orientation(0.0, 0.0, 0.0, 1.0));
        this.pocketWatch.setPositionRelativeToVehicle(new Position(0.143, 1.5, -0.817));
        this.pocketWatch.setScale(new Scale(3.42, 3.42, 3.42));
        this.pocketWatch.getHour().setPositionRelativeToVehicle(new Position(0.0, 0.0, -0.0977));
        this.pocketWatch.getMinute().setPositionRelativeToVehicle(new Position(0.0, 0.0, -0.0977));
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="/* Procedures and functions to handle multiple scenes */">
    @Override
    protected void handleActiveChanged(Boolean isActive, Integer activationCount) {
        if (isActive) {
            if (activationCount == 1) {
                this.performGeneratedSetUp();
                this.performCustomSetup();
                this.initializeEventListeners();
            } else {
                this.restoreStateAndEventListeners();
            }
        } else {
            this.preserveStateAndEventListeners();
        }
    }

    public SRoom getRoom() {
        return this.room;
    }

    public SGround getGround() {
        return this.ground;
    }

    public SCamera getCamera() {
        return this.camera;
    }

    public PocketWatch getPocketWatch() {
        return this.pocketWatch;
    }
    // </editor-fold>
}
