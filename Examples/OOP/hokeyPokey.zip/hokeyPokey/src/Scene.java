// <editor-fold defaultstate="collapsed" desc="imports">

import org.lgna.story.*;
import org.lgna.story.SGround.SurfaceAppearance;
import org.lgna.story.event.SceneActivationEvent;
import org.lgna.story.resources.biped.AliceResource;
import org.lgna.story.resources.biped.YetiBabyResource;
import static org.lgna.common.ThreadUtilities.doTogether;
// </editor-fold>

class Scene extends SScene {

    /* Construct new Scene */
    public Scene() {
        super();
    }

    /* Event listeners */
    private void initializeEventListeners() {
        this.addSceneActivationListener((SceneActivationEvent event) -> {
            this.myFirstMethod();
        });
    }

    /* Procedures and functions for this scene */
    public void myFirstMethod() {
        this.delay(2.0);
        doTogether(() -> {
            this.tortoise.playAudio(new AudioSource(Resources.HokeyPokeySong_wav));
            this.tortoise.playAudio(new AudioSource(Resources.HokeyPokeySong_wav));
        }, () -> {
            this.tortoise.hokeyPokey();
        }, () -> {
            this.tortoise2.hokeyPokey();
        },
        () -> {
            this.alice.hokeyPokey();
        },
        () -> {
            this.yetiBaby.hokeyPokey();
        }
        );
    }
    /* End procedures and functions for this scene */

    // <editor-fold defaultstate="collapsed" desc="/* Scene fields  */">
    private final SGround ground = new SGround();
    private final SCamera camera = new SCamera();
    private final Tortoise tortoise = new Tortoise();
    private final Tortoise tortoise2 = new Tortoise();
    private final YetiBaby yetiBaby = new YetiBaby(YetiBabyResource.TUTU);
    private final Alice alice = new Alice(AliceResource.CARNEGIE_MELLON);
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="/* Scene setup  */">
    private void performCustomSetup() {
//Make adjustments to the starting scene, in a way not available in the Scene editor
    }

    private void performGeneratedSetUp() {
//DO NOT EDIT
//This code is automatically generated.  Any work you perform in this method will be overwritten.
//DO NOT EDIT
        this.setAtmosphereColor(new Color(0.0, 0.0941, 0.294));
        this.setFromAboveLightColor(Color.WHITE);
        this.setFromBelowLightColor(new Color(0.541, 0.0, 0.125));
        this.setFogDensity(0.1);
        this.setName("myScene");
        this.ground.setPaint(SurfaceAppearance.DARK_GRASS);
        this.ground.setOpacity(1.0);
        this.ground.setName("ground");
        this.ground.setVehicle(this);
        this.camera.setName("camera");
        this.camera.setVehicle(this);
        this.camera.setOrientationRelativeToVehicle(new Orientation(0.0, 0.995185, 0.0980144, 6.12323E-17));
        this.camera.setPositionRelativeToVehicle(new Position(9.61E-16, 1.56, -7.85));
        this.tortoise.setPaint(Color.WHITE);
        this.tortoise.setOpacity(1.0);
        this.tortoise.setName("tortoise");
        this.tortoise.setVehicle(this);
        this.tortoise.setOrientationRelativeToVehicle(new Orientation(0.0, 0.0, 0.0, 1.0));
        this.tortoise.setPositionRelativeToVehicle(new Position(0.274, 0.0, -2.31));
        this.tortoise.setScale(new Scale(1.0, 1.0, 1.0));
        this.tortoise2.setPaint(Color.WHITE);
        this.tortoise2.setOpacity(1.0);
        this.tortoise2.setName("tortoise2");
        this.tortoise2.setVehicle(this);
        this.tortoise2.setOrientationRelativeToVehicle(new Orientation(0.0, 0.0, 0.0, 1.0));
        this.tortoise2.setPositionRelativeToVehicle(new Position(1.48, 0.0, -2.2));
        this.tortoise2.setScale(new Scale(1.54, 1.54, 1.54));
        this.tortoise2.getSpineMiddle().setPositionRelativeToVehicle(new Position(-9.76E-17, 3.07E-17, -0.118));
        this.tortoise2.getSpineUpper().setPositionRelativeToVehicle(new Position(-1.38E-16, -1.84E-16, -0.103));
        this.tortoise2.getNeck().setPositionRelativeToVehicle(new Position(-1.45E-31, 7.17E-17, -0.0746));
        this.tortoise2.getHead().setPositionRelativeToVehicle(new Position(-4.85E-32, 3.43E-16, -0.0392));
        this.tortoise2.getMouth().setPositionRelativeToVehicle(new Position(-2.98E-17, 0.0308, -0.0645));
        this.tortoise2.getRightEye().setPositionRelativeToVehicle(new Position(0.0723, 0.0901, -0.0964));
        this.tortoise2.getLeftEye().setPositionRelativeToVehicle(new Position(-0.0723, 0.0901, -0.0964));
        this.tortoise2.getLeftEyelid().setPositionRelativeToVehicle(new Position(-0.0723, 0.0901, -0.0964));
        this.tortoise2.getRightEyelid().setPositionRelativeToVehicle(new Position(0.0723, 0.0901, -0.0964));
        this.tortoise2.getRightHip().setPositionRelativeToVehicle(new Position(0.0571, 0.00106, -0.121));
        this.tortoise2.getRightKnee().setPositionRelativeToVehicle(new Position(-4.1E-17, 3.85E-16, -0.144));
        this.tortoise2.getRightAnkle().setPositionRelativeToVehicle(new Position(2.73E-17, 4.95E-17, -0.151));
        this.tortoise2.getRightFoot().setPositionRelativeToVehicle(new Position(-2.73E-17, 1.09E-16, -0.167));
        this.tortoise2.getLeftHip().setPositionRelativeToVehicle(new Position(-0.0571, 0.00106, -0.121));
        this.tortoise2.getLeftKnee().setPositionRelativeToVehicle(new Position(6.42E-16, -1.22E-16, -0.144));
        this.tortoise2.getLeftAnkle().setPositionRelativeToVehicle(new Position(6.07E-16, -1.74E-16, -0.151));
        this.tortoise2.getLeftFoot().setPositionRelativeToVehicle(new Position(9.11E-13, 0.0, -0.167));
        this.tortoise2.getRightClavicle().setPositionRelativeToVehicle(new Position(0.0174, -0.0436, -0.0428));
        this.tortoise2.getRightShoulder().setPositionRelativeToVehicle(new Position(4.78E-17, 1.72E-12, -0.0709));
        this.tortoise2.getRightElbow().setPositionRelativeToVehicle(new Position(-1.82E-17, -2.76E-14, -0.133));
        this.tortoise2.getRightWrist().setPositionRelativeToVehicle(new Position(-5.67E-17, 3.28E-16, -0.103));
        this.tortoise2.getLeftClavicle().setPositionRelativeToVehicle(new Position(-0.0174, -0.0436, -0.0428));
        this.tortoise2.getLeftShoulder().setPositionRelativeToVehicle(new Position(3.41E-17, 2.18E-16, -0.0709));
        this.tortoise2.getLeftElbow().setPositionRelativeToVehicle(new Position(-1.12E-16, -2.07E-15, -0.133));
        this.tortoise2.getLeftWrist().setPositionRelativeToVehicle(new Position(-6.83E-17, 3.28E-16, -0.103));
        this.yetiBaby.setPaint(Color.WHITE);
        this.yetiBaby.setOpacity(1.0);
        this.yetiBaby.setName("yetiBaby");
        this.yetiBaby.setVehicle(this);
        this.yetiBaby.setOrientationRelativeToVehicle(new Orientation(0.0, 0.0, 0.0, 1.0));
        this.yetiBaby.setPositionRelativeToVehicle(new Position(-0.535, 0.0, -2.33));
        this.yetiBaby.setScale(new Scale(1.0, 1.0, 1.0));
        this.alice.setPaint(Color.WHITE);
        this.alice.setOpacity(1.0);
        this.alice.setName("alice");
        this.alice.setVehicle(this);
        this.alice.setOrientationRelativeToVehicle(new Orientation(0.0, 0.0, 0.0, 1.0));
        this.alice.setPositionRelativeToVehicle(new Position(-1.61, 0.0, -2.51));
        this.alice.setScale(new Scale(1.0, 1.0, 1.0));
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="/* Procedures and functions to handle multiple scenes */">
    @Override
    protected void handleActiveChanged(Boolean isActive, Integer activationCount) {
        if (isActive) {
            if (activationCount == 1) {
                this.performGeneratedSetUp();
                this.performCustomSetup();
                this.initializeEventListeners();
            } else {
                this.restoreStateAndEventListeners();
            }
        } else {
            this.preserveStateAndEventListeners();
        }
    }

    public SGround getGround() {
        return this.ground;
    }

    public SCamera getCamera() {
        return this.camera;
    }

    public Tortoise getTortoise() {
        return this.tortoise;
    }

    public Tortoise getTortoise2() {
        return this.tortoise2;
    }

    public YetiBaby getYetiBaby() {
        return this.yetiBaby;
    }

    public Alice getAlice() {
        return this.alice;
    }
    // </editor-fold>
}
