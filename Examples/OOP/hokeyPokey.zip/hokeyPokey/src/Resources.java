// <editor-fold defaultstate="collapsed" desc="imports">

import org.lgna.common.resources.AudioResource;
// </editor-fold>

class Resources extends Object {

    public static final AudioResource HokeyPokeySong_wav = new AudioResource(Resources.class, "resources/HokeyPokeySong.wav", "audio.x_wav");
}
