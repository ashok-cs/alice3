// <editor-fold defaultstate="collapsed" desc="imports">

import org.lgna.story.*;
import org.lgna.story.resources.flyer.ChickenResource;
import org.lgna.story.SGround.SurfaceAppearance;
import org.lgna.story.event.SceneActivationEvent;
// </editor-fold>

class Scene extends SScene {

    /* Construct new Scene */
    public Scene() {
        super();
    }

    /* Event listeners */
    private void initializeEventListeners() {
        this.addSceneActivationListener((SceneActivationEvent event) -> {
            this.myFirstMethod();
        });
    }

    /* Procedures and functions for this scene */
    public void myFirstMethod() {
       this.delay(3);
       this.chicken2.setPaint(Color.DARK_GRAY);
    }
    /* End procedures and functions for this scene */

    // <editor-fold defaultstate="collapsed" desc="/* Scene fields  */">
    private final SGround ground = new SGround();
    private final SCamera camera = new SCamera();
    private final Chicken chicken = new Chicken(ChickenResource.DEFAULT);
    private final Chicken chicken2 = new Chicken(ChickenResource.DEFAULT);
    private final Chicken chicken3 = new Chicken(ChickenResource.DEFAULT);
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="/* Scene setup  */">
    private void performCustomSetup() {
//Make adjustments to the starting scene, in a way not available in the Scene editor
        
        this.chicken2.setPaint(Color.RED);
    }

    private void performGeneratedSetUp() {
//DO NOT EDIT
//This code is automatically generated.  Any work you perform in this method will be overwritten.
//DO NOT EDIT
        this.setAtmosphereColor(new Color(0.514, 0.376, 0.278));
        this.setFromAboveLightColor(Color.WHITE);
        this.setFromBelowLightColor(new Color(0.384, 0.0, 0.22));
        this.setFogDensity(0.0);
        this.setName("myScene");
        this.ground.setPaint(SurfaceAppearance.ROCKY_BROWN);
        this.ground.setOpacity(1.0);
        this.ground.setName("ground");
        this.ground.setVehicle(this);
        this.camera.setName("camera");
        this.camera.setVehicle(this);
        this.camera.setOrientationRelativeToVehicle(new Orientation(0.0, 0.995185, 0.0980144, 6.12323E-17));
        this.camera.setPositionRelativeToVehicle(new Position(9.61E-16, 1.56, -7.85));
        //this.chicken.setPaint(Color.WHITE);
        this.chicken.setOpacity(1.0);
        this.chicken.setName("chicken");
        this.chicken.setVehicle(this);
        this.chicken.setOrientationRelativeToVehicle(new Orientation(0.0, 0.0, 0.0, 1.0));
        this.chicken.setPositionRelativeToVehicle(new Position(0.387, 0.0, -2.81));
        this.chicken.setScale(new Scale(1.0, 1.0, 1.0));
        //this.chicken2.setPaint(Color.WHITE);
        this.chicken2.setOpacity(1.0);
        this.chicken2.setName("chicken2");
        this.chicken2.setVehicle(this);
        this.chicken2.setOrientationRelativeToVehicle(new Orientation(0.0, 0.0, 0.0, 1.0));
        this.chicken2.setPositionRelativeToVehicle(new Position(-1.02, 0.0, -3.12));
        this.chicken2.setScale(new Scale(1.0, 1.0, 1.0));
        //this.chicken3.setPaint(Color.WHITE);
        this.chicken3.setOpacity(1.0);
        this.chicken3.setName("chicken3");
        this.chicken3.setVehicle(this);
        this.chicken3.setOrientationRelativeToVehicle(new Orientation(0.0, 0.0, 0.0, 1.0));
        this.chicken3.setPositionRelativeToVehicle(new Position(1.77, 0.0, -2.61));
        this.chicken3.setScale(new Scale(1.0, 1.0, 1.0));
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="/* Procedures and functions to handle multiple scenes */">
    @Override
    protected void handleActiveChanged(Boolean isActive, Integer activationCount) {
        if (isActive) {
            if (activationCount == 1) {
                this.performGeneratedSetUp();
                this.performCustomSetup();
                this.initializeEventListeners();
            } else {
                this.restoreStateAndEventListeners();
            }
        } else {
            this.preserveStateAndEventListeners();
        }
    }

    public SGround getGround() {
        return this.ground;
    }

    public SCamera getCamera() {
        return this.camera;
    }

    public Chicken getChicken() {
        return this.chicken;
    }

    public Chicken getChicken2() {
        return this.chicken2;
    }

    public Chicken getChicken3() {
        return this.chicken3;
    }
    // </editor-fold>
}
