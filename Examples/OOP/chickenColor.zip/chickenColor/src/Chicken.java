// <editor-fold defaultstate="collapsed" desc="imports">

import org.lgna.story.Color;
import org.lgna.story.resources.flyer.ChickenResource;
// </editor-fold>

class Chicken extends Flyer {

    /* Construct new Chicken */
    public Chicken(ChickenResource resource) {
        super(resource);
        this.setPaint(Color.YELLOW);
    }

    public void setChickenResource(ChickenResource chickenResource) {
        this.setJointedModelResource(chickenResource);
    }
}
