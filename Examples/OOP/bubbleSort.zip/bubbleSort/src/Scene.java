// <editor-fold defaultstate="collapsed" desc="imports">

import org.lgna.story.*;
import org.lgna.story.SGround.SurfaceAppearance;
import org.lgna.story.resources.biped.PlayingCardResource;
import org.lgna.story.event.SceneActivationEvent;
// </editor-fold>

class Scene extends SScene {

    /* Construct new Scene */
    public Scene() {
        super();
    }

    /* Event listeners */
    private void initializeEventListeners() {
        this.addSceneActivationListener((SceneActivationEvent event) -> {
            this.myFirstMethod();
        });
    }

    /* Procedures and functions for this scene */
    public void myFirstMethod() {
        PlayingCard[] card = new PlayingCard[]{this.c7, this.c5, this.c4, this.c9, this.c1};
        Disc[] disc = new Disc[]{this.d1, this.d2, this.d3, this.d4, this.d5};
        
        PlayingCard temp;
        boolean swap=true;
        
        while(swap==true){
            swap=false;
            for(int i=0;i<card.length-1;i++){
                if(card[i].getHeight()>card[i+1].getHeight()){
                    card[i].moveTo(disc[i+1]);
                    card[i+1].moveTo(disc[i]);
                    temp=card[i+1];
                    card[i+1]=card[i];
                    card[i]=temp;
                    swap=true;                
                }
            
            }
        
        }
        
    }
    /* End procedures and functions for this scene */

    // <editor-fold defaultstate="collapsed" desc="/* Scene fields  */">
    private final SGround ground = new SGround();
    private final SCamera camera = new SCamera();
    private final PlayingCard c7 = new PlayingCard(PlayingCardResource.EIGHT8);
    private final PlayingCard c5 = new PlayingCard(PlayingCardResource.FIVE5);
    private final PlayingCard c4 = new PlayingCard(PlayingCardResource.FOUR4);
    private final PlayingCard c9 = new PlayingCard(PlayingCardResource.NINE9);
    private final PlayingCard c1 = new PlayingCard(PlayingCardResource.ONE1);
    private final Disc d1 = new Disc();
    private final Disc d2 = new Disc();
    private final Disc d3 = new Disc();
    private final Disc d4 = new Disc();
    private final Disc d5 = new Disc();
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="/* Scene setup  */">
    private void performCustomSetup() {
//Make adjustments to the starting scene, in a way not available in the Scene editor
    }

    private void performGeneratedSetUp() {
//DO NOT EDIT
//This code is automatically generated.  Any work you perform in this method will be overwritten.
//DO NOT EDIT
        this.setAtmosphereColor(new Color(0.588, 0.886, 0.988));
        this.setFromAboveLightColor(Color.WHITE);
        this.setFromBelowLightColor(Color.BLACK);
        this.setFogDensity(0.0);
        this.setName("myScene");
        this.ground.setPaint(SurfaceAppearance.GRASS);
        this.ground.setOpacity(1.0);
        this.ground.setName("ground");
        this.ground.setVehicle(this);
        this.camera.setName("camera");
        this.camera.setVehicle(this);
        this.camera.setOrientationRelativeToVehicle(new Orientation(0.0, 0.995185, 0.0980144, 6.12323E-17));
        this.camera.setPositionRelativeToVehicle(new Position(9.61E-16, 1.56, -7.85));
        this.c7.setPaint(Color.WHITE);
        this.c7.setOpacity(1.0);
        this.c7.setName("c7");
        this.c7.setVehicle(this);
        this.c7.setOrientationRelativeToVehicle(new Orientation(0.0, 0.0, 0.0, 1.0));
        this.c7.setPositionRelativeToVehicle(new Position(1.21, 0.0, -1.32));
        this.c7.setScale(new Scale(1.05, 1.05, 1.05));
        this.c7.getSpineMiddle().setPositionRelativeToVehicle(new Position(0.0, 0.0, -0.21));
        this.c7.getSpineUpper().setPositionRelativeToVehicle(new Position(3.53E-19, 5.61E-17, -0.279));
        this.c7.getNeck().setPositionRelativeToVehicle(new Position(-4.91E-17, 0.0, -0.116));
        this.c7.getHead().setPositionRelativeToVehicle(new Position(4.09E-16, 0.0, -0.0606));
        this.c7.getMouth().setPositionRelativeToVehicle(new Position(1.79E-15, 0.0317, -0.0405));
        this.c7.getRightEye().setPositionRelativeToVehicle(new Position(0.0525, 0.197, -0.0885));
        this.c7.getLeftEye().setPositionRelativeToVehicle(new Position(-0.0525, 0.197, -0.0885));
        this.c7.getLeftEyelid().setPositionRelativeToVehicle(new Position(-0.0525, 0.197, -0.0885));
        this.c7.getRightEyelid().setPositionRelativeToVehicle(new Position(0.0525, 0.197, -0.0885));
        this.c7.getRightHip().setPositionRelativeToVehicle(new Position(0.134, 0.0306, -0.103));
        this.c7.getRightKnee().setPositionRelativeToVehicle(new Position(1.87E-17, 1.37E-15, -0.216));
        this.c7.getRightAnkle().setPositionRelativeToVehicle(new Position(1.87E-17, 6.17E-16, -0.243));
        this.c7.getRightFoot().setPositionRelativeToVehicle(new Position(-5.61E-17, -1.4E-16, -0.173));
        this.c7.getLeftHip().setPositionRelativeToVehicle(new Position(-0.134, 0.0306, -0.103));
        this.c7.getLeftKnee().setPositionRelativeToVehicle(new Position(3.74E-17, 4.77E-16, -0.216));
        this.c7.getLeftAnkle().setPositionRelativeToVehicle(new Position(7.48E-17, -2.34E-16, -0.243));
        this.c7.getLeftFoot().setPositionRelativeToVehicle(new Position(1.33E-15, 0.0, -0.173));
        this.c7.getRightClavicle().setPositionRelativeToVehicle(new Position(0.111, -0.029, -0.00831));
        this.c7.getRightShoulder().setPositionRelativeToVehicle(new Position(7.25E-17, 2.99E-16, -0.119));
        this.c7.getRightElbow().setPositionRelativeToVehicle(new Position(-5.33E-16, 0.0, -0.253));
        this.c7.getRightWrist().setPositionRelativeToVehicle(new Position(-3.74E-16, 1.5E-16, -0.239));
        this.c7.getRightHand().setPositionRelativeToVehicle(new Position(-1.22E-16, -2.99E-16, -0.057));
        this.c7.getRightThumb().setPositionRelativeToVehicle(new Position(1.5E-16, 5.99E-16, -0.0452));
        this.c7.getRightThumbKnuckle().setPositionRelativeToVehicle(new Position(-5.99E-16, -2.99E-16, -0.0392));
        this.c7.getRightIndexFinger().setPositionRelativeToVehicle(new Position(0.0772, 0.00204, -0.0437));
        this.c7.getRightIndexFingerKnuckle().setPositionRelativeToVehicle(new Position(-7.48E-17, -1.37E-12, -0.041));
        this.c7.getRightMiddleFinger().setPositionRelativeToVehicle(new Position(0.0867, 0.00394, -0.025));
        this.c7.getRightMiddleFingerKnuckle().setPositionRelativeToVehicle(new Position(1.12E-16, -4.49E-16, -0.0435));
        this.c7.getRightPinkyFinger().setPositionRelativeToVehicle(new Position(0.0829, -5.99E-16, 0.0241));
        this.c7.getRightPinkyFingerKnuckle().setPositionRelativeToVehicle(new Position(-4.68E-17, -6.88E-14, -0.0326));
        this.c7.getLeftClavicle().setPositionRelativeToVehicle(new Position(-0.111, -0.029, -0.00831));
        this.c7.getLeftShoulder().setPositionRelativeToVehicle(new Position(-6.31E-17, 2.99E-16, -0.119));
        this.c7.getLeftElbow().setPositionRelativeToVehicle(new Position(2.99E-16, 1.43E-13, -0.253));
        this.c7.getLeftWrist().setPositionRelativeToVehicle(new Position(3.09E-16, 1.36E-13, -0.239));
        this.c7.getLeftHand().setPositionRelativeToVehicle(new Position(1.22E-16, 2.99E-16, -0.057));
        this.c7.getLeftThumb().setPositionRelativeToVehicle(new Position(-2.99E-16, -4.49E-16, -0.0452));
        this.c7.getLeftThumbKnuckle().setPositionRelativeToVehicle(new Position(-1.5E-16, -1.66E-14, -0.0392));
        this.c7.getLeftIndexFinger().setPositionRelativeToVehicle(new Position(-0.0772, 0.00204, -0.0437));
        this.c7.getLeftIndexFingerKnuckle().setPositionRelativeToVehicle(new Position(-5.61E-17, 1.05E-15, -0.041));
        this.c7.getLeftMiddleFinger().setPositionRelativeToVehicle(new Position(-0.0867, 0.00394, -0.025));
        this.c7.getLeftMiddleFingerKnuckle().setPositionRelativeToVehicle(new Position(-4.68E-17, 2.69E-15, -0.0435));
        this.c7.getLeftPinkyFinger().setPositionRelativeToVehicle(new Position(-0.0829, -1.5E-15, 0.0241));
        this.c7.getLeftPinkyFingerKnuckle().setPositionRelativeToVehicle(new Position(-5.61E-17, 1.8E-15, -0.0326));
        this.c5.setPaint(Color.WHITE);
        this.c5.setOpacity(1.0);
        this.c5.setName("c5");
        this.c5.setVehicle(this);
        this.c5.setOrientationRelativeToVehicle(new Orientation(0.0, 0.0, 0.0, 1.0));
        this.c5.setPositionRelativeToVehicle(new Position(-0.117, 0.0, -1.52));
        this.c5.setScale(new Scale(0.929, 0.929, 0.929));
        this.c5.getSpineMiddle().setPositionRelativeToVehicle(new Position(0.0, 0.0, -0.185));
        this.c5.getSpineUpper().setPositionRelativeToVehicle(new Position(3.12E-19, 4.95E-17, -0.246));
        this.c5.getNeck().setPositionRelativeToVehicle(new Position(-4.33E-17, 0.0, -0.103));
        this.c5.getHead().setPositionRelativeToVehicle(new Position(3.61E-16, 0.0, -0.0535));
        this.c5.getMouth().setPositionRelativeToVehicle(new Position(1.58E-15, 0.028, -0.0358));
        this.c5.getRightEye().setPositionRelativeToVehicle(new Position(0.0463, 0.173, -0.0781));
        this.c5.getLeftEye().setPositionRelativeToVehicle(new Position(-0.0463, 0.173, -0.0781));
        this.c5.getLeftEyelid().setPositionRelativeToVehicle(new Position(-0.0463, 0.173, -0.0781));
        this.c5.getRightEyelid().setPositionRelativeToVehicle(new Position(0.0463, 0.173, -0.0781));
        this.c5.getRightHip().setPositionRelativeToVehicle(new Position(0.119, 0.027, -0.091));
        this.c5.getRightKnee().setPositionRelativeToVehicle(new Position(1.65E-17, 1.2E-15, -0.19));
        this.c5.getRightAnkle().setPositionRelativeToVehicle(new Position(1.65E-17, 5.45E-16, -0.215));
        this.c5.getRightFoot().setPositionRelativeToVehicle(new Position(-4.95E-17, -1.24E-16, -0.152));
        this.c5.getLeftHip().setPositionRelativeToVehicle(new Position(-0.119, 0.027, -0.091));
        this.c5.getLeftKnee().setPositionRelativeToVehicle(new Position(3.3E-17, 4.21E-16, -0.19));
        this.c5.getLeftAnkle().setPositionRelativeToVehicle(new Position(6.6E-17, -2.06E-16, -0.215));
        this.c5.getLeftFoot().setPositionRelativeToVehicle(new Position(1.17E-15, 0.0, -0.152));
        this.c5.getRightClavicle().setPositionRelativeToVehicle(new Position(0.0984, -0.0255, -0.00734));
        this.c5.getRightShoulder().setPositionRelativeToVehicle(new Position(6.4E-17, 2.64E-16, -0.105));
        this.c5.getRightElbow().setPositionRelativeToVehicle(new Position(-4.7E-16, 0.0, -0.224));
        this.c5.getRightWrist().setPositionRelativeToVehicle(new Position(-3.3E-16, 1.32E-16, -0.211));
        this.c5.getRightHand().setPositionRelativeToVehicle(new Position(-1.07E-16, -2.64E-16, -0.0503));
        this.c5.getRightThumb().setPositionRelativeToVehicle(new Position(1.32E-16, 5.28E-16, -0.0399));
        this.c5.getRightThumbKnuckle().setPositionRelativeToVehicle(new Position(-5.28E-16, -2.64E-16, -0.0346));
        this.c5.getRightIndexFinger().setPositionRelativeToVehicle(new Position(0.0682, 0.0018, -0.0385));
        this.c5.getRightIndexFingerKnuckle().setPositionRelativeToVehicle(new Position(-6.6E-17, -1.21E-12, -0.0362));
        this.c5.getRightMiddleFinger().setPositionRelativeToVehicle(new Position(0.0765, 0.00348, -0.022));
        this.c5.getRightMiddleFingerKnuckle().setPositionRelativeToVehicle(new Position(9.9E-17, -3.96E-16, -0.0384));
        this.c5.getRightPinkyFinger().setPositionRelativeToVehicle(new Position(0.0731, -5.28E-16, 0.0212));
        this.c5.getRightPinkyFingerKnuckle().setPositionRelativeToVehicle(new Position(-4.13E-17, -6.07E-14, -0.0288));
        this.c5.getLeftClavicle().setPositionRelativeToVehicle(new Position(-0.0984, -0.0255, -0.00734));
        this.c5.getLeftShoulder().setPositionRelativeToVehicle(new Position(-5.57E-17, 2.64E-16, -0.105));
        this.c5.getLeftElbow().setPositionRelativeToVehicle(new Position(2.64E-16, 1.26E-13, -0.224));
        this.c5.getLeftWrist().setPositionRelativeToVehicle(new Position(2.72E-16, 1.2E-13, -0.211));
        this.c5.getLeftHand().setPositionRelativeToVehicle(new Position(1.07E-16, 2.64E-16, -0.0503));
        this.c5.getLeftThumb().setPositionRelativeToVehicle(new Position(-2.64E-16, -3.96E-16, -0.0399));
        this.c5.getLeftThumbKnuckle().setPositionRelativeToVehicle(new Position(-1.32E-16, -1.47E-14, -0.0346));
        this.c5.getLeftIndexFinger().setPositionRelativeToVehicle(new Position(-0.0682, 0.0018, -0.0385));
        this.c5.getLeftIndexFingerKnuckle().setPositionRelativeToVehicle(new Position(-4.95E-17, 9.24E-16, -0.0362));
        this.c5.getLeftMiddleFinger().setPositionRelativeToVehicle(new Position(-0.0765, 0.00348, -0.022));
        this.c5.getLeftMiddleFingerKnuckle().setPositionRelativeToVehicle(new Position(-4.13E-17, 2.38E-15, -0.0384));
        this.c5.getLeftPinkyFinger().setPositionRelativeToVehicle(new Position(-0.0731, -1.32E-15, 0.0212));
        this.c5.getLeftPinkyFingerKnuckle().setPositionRelativeToVehicle(new Position(-4.95E-17, 1.58E-15, -0.0288));
        this.c4.setPaint(Color.WHITE);
        this.c4.setOpacity(1.0);
        this.c4.setName("c4");
        this.c4.setVehicle(this);
        this.c4.setOrientationRelativeToVehicle(new Orientation(0.0, 0.0, 0.0, 1.0));
        this.c4.setPositionRelativeToVehicle(new Position(2.47, 0.0, -1.03));
        this.c4.setScale(new Scale(0.867, 0.867, 0.867));
        this.c4.getSpineMiddle().setPositionRelativeToVehicle(new Position(0.0, 0.0, -0.173));
        this.c4.getSpineUpper().setPositionRelativeToVehicle(new Position(2.91E-19, 4.62E-17, -0.23));
        this.c4.getNeck().setPositionRelativeToVehicle(new Position(-4.04E-17, 0.0, -0.0958));
        this.c4.getHead().setPositionRelativeToVehicle(new Position(3.37E-16, 0.0, -0.0499));
        this.c4.getMouth().setPositionRelativeToVehicle(new Position(1.48E-15, 0.0261, -0.0334));
        this.c4.getRightEye().setPositionRelativeToVehicle(new Position(0.0432, 0.162, -0.0729));
        this.c4.getLeftEye().setPositionRelativeToVehicle(new Position(-0.0432, 0.162, -0.0729));
        this.c4.getLeftEyelid().setPositionRelativeToVehicle(new Position(-0.0432, 0.162, -0.0729));
        this.c4.getRightEyelid().setPositionRelativeToVehicle(new Position(0.0432, 0.162, -0.0729));
        this.c4.getRightHip().setPositionRelativeToVehicle(new Position(0.111, 0.0252, -0.0849));
        this.c4.getRightKnee().setPositionRelativeToVehicle(new Position(1.54E-17, 1.12E-15, -0.178));
        this.c4.getRightAnkle().setPositionRelativeToVehicle(new Position(1.54E-17, 5.08E-16, -0.201));
        this.c4.getRightFoot().setPositionRelativeToVehicle(new Position(-4.62E-17, -1.16E-16, -0.142));
        this.c4.getLeftHip().setPositionRelativeToVehicle(new Position(-0.111, 0.0252, -0.0849));
        this.c4.getLeftKnee().setPositionRelativeToVehicle(new Position(3.08E-17, 3.93E-16, -0.178));
        this.c4.getLeftAnkle().setPositionRelativeToVehicle(new Position(6.16E-17, -1.93E-16, -0.201));
        this.c4.getLeftFoot().setPositionRelativeToVehicle(new Position(1.09E-15, 0.0, -0.142));
        this.c4.getRightClavicle().setPositionRelativeToVehicle(new Position(0.0918, -0.0238, -0.00685));
        this.c4.getRightShoulder().setPositionRelativeToVehicle(new Position(5.97E-17, 2.46E-16, -0.0983));
        this.c4.getRightElbow().setPositionRelativeToVehicle(new Position(-4.39E-16, 0.0, -0.209));
        this.c4.getRightWrist().setPositionRelativeToVehicle(new Position(-3.08E-16, 1.23E-16, -0.197));
        this.c4.getRightHand().setPositionRelativeToVehicle(new Position(-1.0E-16, -2.46E-16, -0.0469));
        this.c4.getRightThumb().setPositionRelativeToVehicle(new Position(1.23E-16, 4.93E-16, -0.0372));
        this.c4.getRightThumbKnuckle().setPositionRelativeToVehicle(new Position(-4.93E-16, -2.46E-16, -0.0323));
        this.c4.getRightIndexFinger().setPositionRelativeToVehicle(new Position(0.0636, 0.00168, -0.036));
        this.c4.getRightIndexFingerKnuckle().setPositionRelativeToVehicle(new Position(-6.16E-17, -1.13E-12, -0.0338));
        this.c4.getRightMiddleFinger().setPositionRelativeToVehicle(new Position(0.0714, 0.00324, -0.0206));
        this.c4.getRightMiddleFingerKnuckle().setPositionRelativeToVehicle(new Position(9.24E-17, -3.7E-16, -0.0359));
        this.c4.getRightPinkyFinger().setPositionRelativeToVehicle(new Position(0.0682, -4.93E-16, 0.0198));
        this.c4.getRightPinkyFingerKnuckle().setPositionRelativeToVehicle(new Position(-3.85E-17, -5.67E-14, -0.0268));
        this.c4.getLeftClavicle().setPositionRelativeToVehicle(new Position(-0.0918, -0.0238, -0.00685));
        this.c4.getLeftShoulder().setPositionRelativeToVehicle(new Position(-5.2E-17, 2.46E-16, -0.0983));
        this.c4.getLeftElbow().setPositionRelativeToVehicle(new Position(2.46E-16, 1.18E-13, -0.209));
        this.c4.getLeftWrist().setPositionRelativeToVehicle(new Position(2.54E-16, 1.12E-13, -0.197));
        this.c4.getLeftHand().setPositionRelativeToVehicle(new Position(1.0E-16, 2.46E-16, -0.0469));
        this.c4.getLeftThumb().setPositionRelativeToVehicle(new Position(-2.46E-16, -3.7E-16, -0.0372));
        this.c4.getLeftThumbKnuckle().setPositionRelativeToVehicle(new Position(-1.23E-16, -1.37E-14, -0.0323));
        this.c4.getLeftIndexFinger().setPositionRelativeToVehicle(new Position(-0.0636, 0.00168, -0.036));
        this.c4.getLeftIndexFingerKnuckle().setPositionRelativeToVehicle(new Position(-4.62E-17, 8.63E-16, -0.0338));
        this.c4.getLeftMiddleFinger().setPositionRelativeToVehicle(new Position(-0.0714, 0.00324, -0.0206));
        this.c4.getLeftMiddleFingerKnuckle().setPositionRelativeToVehicle(new Position(-3.85E-17, 2.22E-15, -0.0359));
        this.c4.getLeftPinkyFinger().setPositionRelativeToVehicle(new Position(-0.0682, -1.23E-15, 0.0198));
        this.c4.getLeftPinkyFingerKnuckle().setPositionRelativeToVehicle(new Position(-4.62E-17, 1.48E-15, -0.0268));
        this.c9.setPaint(Color.WHITE);
        this.c9.setOpacity(1.0);
        this.c9.setName("c9");
        this.c9.setVehicle(this);
        this.c9.setOrientationRelativeToVehicle(new Orientation(0.0, 0.0, 0.0, 1.0));
        this.c9.setPositionRelativeToVehicle(new Position(-1.35, 0.0, -1.21));
        this.c9.setScale(new Scale(1.18, 1.18, 1.18));
        this.c9.getSpineMiddle().setPositionRelativeToVehicle(new Position(0.0, 0.0, -0.234));
        this.c9.getSpineUpper().setPositionRelativeToVehicle(new Position(3.95E-19, 6.27E-17, -0.312));
        this.c9.getNeck().setPositionRelativeToVehicle(new Position(-5.49E-17, 0.0, -0.13));
        this.c9.getHead().setPositionRelativeToVehicle(new Position(4.57E-16, 0.0, -0.0678));
        this.c9.getMouth().setPositionRelativeToVehicle(new Position(2.01E-15, 0.0355, -0.0453));
        this.c9.getRightEye().setPositionRelativeToVehicle(new Position(0.0586, 0.22, -0.0989));
        this.c9.getLeftEye().setPositionRelativeToVehicle(new Position(-0.0586, 0.22, -0.0989));
        this.c9.getLeftEyelid().setPositionRelativeToVehicle(new Position(-0.0586, 0.22, -0.0989));
        this.c9.getRightEyelid().setPositionRelativeToVehicle(new Position(0.0586, 0.22, -0.0989));
        this.c9.getRightHip().setPositionRelativeToVehicle(new Position(0.15, 0.0342, -0.115));
        this.c9.getRightKnee().setPositionRelativeToVehicle(new Position(2.09E-17, 1.53E-15, -0.241));
        this.c9.getRightAnkle().setPositionRelativeToVehicle(new Position(2.09E-17, 6.9E-16, -0.272));
        this.c9.getRightFoot().setPositionRelativeToVehicle(new Position(-6.27E-17, -1.57E-16, -0.193));
        this.c9.getLeftHip().setPositionRelativeToVehicle(new Position(-0.15, 0.0342, -0.115));
        this.c9.getLeftKnee().setPositionRelativeToVehicle(new Position(4.18E-17, 5.33E-16, -0.241));
        this.c9.getLeftAnkle().setPositionRelativeToVehicle(new Position(8.36E-17, -2.61E-16, -0.272));
        this.c9.getLeftFoot().setPositionRelativeToVehicle(new Position(1.48E-15, 0.0, -0.193));
        this.c9.getRightClavicle().setPositionRelativeToVehicle(new Position(0.125, -0.0324, -0.00929));
        this.c9.getRightShoulder().setPositionRelativeToVehicle(new Position(8.1E-17, 3.35E-16, -0.133));
        this.c9.getRightElbow().setPositionRelativeToVehicle(new Position(-5.96E-16, 0.0, -0.283));
        this.c9.getRightWrist().setPositionRelativeToVehicle(new Position(-4.18E-16, 1.67E-16, -0.268));
        this.c9.getRightHand().setPositionRelativeToVehicle(new Position(-1.36E-16, -3.35E-16, -0.0637));
        this.c9.getRightThumb().setPositionRelativeToVehicle(new Position(1.67E-16, 6.69E-16, -0.0505));
        this.c9.getRightThumbKnuckle().setPositionRelativeToVehicle(new Position(-6.69E-16, -3.35E-16, -0.0438));
        this.c9.getRightIndexFinger().setPositionRelativeToVehicle(new Position(0.0863, 0.00228, -0.0488));
        this.c9.getRightIndexFingerKnuckle().setPositionRelativeToVehicle(new Position(-8.36E-17, -1.53E-12, -0.0459));
        this.c9.getRightMiddleFinger().setPositionRelativeToVehicle(new Position(0.0969, 0.0044, -0.0279));
        this.c9.getRightMiddleFingerKnuckle().setPositionRelativeToVehicle(new Position(1.25E-16, -5.02E-16, -0.0487));
        this.c9.getRightPinkyFinger().setPositionRelativeToVehicle(new Position(0.0926, -6.69E-16, 0.0269));
        this.c9.getRightPinkyFingerKnuckle().setPositionRelativeToVehicle(new Position(-5.23E-17, -7.69E-14, -0.0364));
        this.c9.getLeftClavicle().setPositionRelativeToVehicle(new Position(-0.125, -0.0324, -0.00929));
        this.c9.getLeftShoulder().setPositionRelativeToVehicle(new Position(-7.06E-17, 3.35E-16, -0.133));
        this.c9.getLeftElbow().setPositionRelativeToVehicle(new Position(3.35E-16, 1.6E-13, -0.283));
        this.c9.getLeftWrist().setPositionRelativeToVehicle(new Position(3.45E-16, 1.52E-13, -0.268));
        this.c9.getLeftHand().setPositionRelativeToVehicle(new Position(1.36E-16, 3.35E-16, -0.0637));
        this.c9.getLeftThumb().setPositionRelativeToVehicle(new Position(-3.35E-16, -5.02E-16, -0.0505));
        this.c9.getLeftThumbKnuckle().setPositionRelativeToVehicle(new Position(-1.67E-16, -1.86E-14, -0.0438));
        this.c9.getLeftIndexFinger().setPositionRelativeToVehicle(new Position(-0.0863, 0.00228, -0.0488));
        this.c9.getLeftIndexFingerKnuckle().setPositionRelativeToVehicle(new Position(-6.27E-17, 1.17E-15, -0.0459));
        this.c9.getLeftMiddleFinger().setPositionRelativeToVehicle(new Position(-0.0969, 0.0044, -0.0279));
        this.c9.getLeftMiddleFingerKnuckle().setPositionRelativeToVehicle(new Position(-5.23E-17, 3.01E-15, -0.0487));
        this.c9.getLeftPinkyFinger().setPositionRelativeToVehicle(new Position(-0.0926, -1.67E-15, 0.0269));
        this.c9.getLeftPinkyFingerKnuckle().setPositionRelativeToVehicle(new Position(-6.27E-17, 2.01E-15, -0.0364));
        this.c1.setPaint(Color.WHITE);
        this.c1.setOpacity(1.0);
        this.c1.setName("c1");
        this.c1.setVehicle(this);
        this.c1.setOrientationRelativeToVehicle(new Orientation(0.0, 0.0, 0.0, 1.0));
        this.c1.setPositionRelativeToVehicle(new Position(-2.52, 0.0, -1.18));
        this.c1.setScale(new Scale(0.681, 0.681, 0.681));
        this.c1.getSpineMiddle().setPositionRelativeToVehicle(new Position(0.0, 0.0, -0.136));
        this.c1.getSpineUpper().setPositionRelativeToVehicle(new Position(2.29E-19, 3.63E-17, -0.181));
        this.c1.getNeck().setPositionRelativeToVehicle(new Position(-3.18E-17, 0.0, -0.0752));
        this.c1.getHead().setPositionRelativeToVehicle(new Position(2.64E-16, 0.0, -0.0392));
        this.c1.getMouth().setPositionRelativeToVehicle(new Position(1.16E-15, 0.0205, -0.0262));
        this.c1.getRightEye().setPositionRelativeToVehicle(new Position(0.0339, 0.127, -0.0573));
        this.c1.getLeftEye().setPositionRelativeToVehicle(new Position(-0.0339, 0.127, -0.0573));
        this.c1.getLeftEyelid().setPositionRelativeToVehicle(new Position(-0.0339, 0.127, -0.0573));
        this.c1.getRightEyelid().setPositionRelativeToVehicle(new Position(0.0339, 0.127, -0.0573));
        this.c1.getRightHip().setPositionRelativeToVehicle(new Position(0.0869, 0.0198, -0.0667));
        this.c1.getRightKnee().setPositionRelativeToVehicle(new Position(1.21E-17, 8.84E-16, -0.14));
        this.c1.getRightAnkle().setPositionRelativeToVehicle(new Position(1.21E-17, 3.99E-16, -0.158));
        this.c1.getRightFoot().setPositionRelativeToVehicle(new Position(-3.63E-17, -9.08E-17, -0.112));
        this.c1.getLeftHip().setPositionRelativeToVehicle(new Position(-0.0869, 0.0198, -0.0667));
        this.c1.getLeftKnee().setPositionRelativeToVehicle(new Position(2.42E-17, 3.09E-16, -0.14));
        this.c1.getLeftAnkle().setPositionRelativeToVehicle(new Position(4.84E-17, -1.51E-16, -0.158));
        this.c1.getLeftFoot().setPositionRelativeToVehicle(new Position(8.59E-16, 0.0, -0.112));
        this.c1.getRightClavicle().setPositionRelativeToVehicle(new Position(0.0721, -0.0187, -0.00538));
        this.c1.getRightShoulder().setPositionRelativeToVehicle(new Position(4.69E-17, 1.94E-16, -0.0772));
        this.c1.getRightElbow().setPositionRelativeToVehicle(new Position(-3.45E-16, 0.0, -0.164));
        this.c1.getRightWrist().setPositionRelativeToVehicle(new Position(-2.42E-16, 9.68E-17, -0.155));
        this.c1.getRightHand().setPositionRelativeToVehicle(new Position(-7.87E-17, -1.94E-16, -0.0369));
        this.c1.getRightThumb().setPositionRelativeToVehicle(new Position(9.68E-17, 3.87E-16, -0.0292));
        this.c1.getRightThumbKnuckle().setPositionRelativeToVehicle(new Position(-3.87E-16, -1.94E-16, -0.0253));
        this.c1.getRightIndexFinger().setPositionRelativeToVehicle(new Position(0.05, 0.00132, -0.0283));
        this.c1.getRightIndexFingerKnuckle().setPositionRelativeToVehicle(new Position(-4.84E-17, -8.84E-13, -0.0266));
        this.c1.getRightMiddleFinger().setPositionRelativeToVehicle(new Position(0.0561, 0.00255, -0.0162));
        this.c1.getRightMiddleFingerKnuckle().setPositionRelativeToVehicle(new Position(7.26E-17, -2.9E-16, -0.0282));
        this.c1.getRightPinkyFinger().setPositionRelativeToVehicle(new Position(0.0536, -3.87E-16, 0.0156));
        this.c1.getRightPinkyFingerKnuckle().setPositionRelativeToVehicle(new Position(-3.03E-17, -4.45E-14, -0.0211));
        this.c1.getLeftClavicle().setPositionRelativeToVehicle(new Position(-0.0721, -0.0187, -0.00538));
        this.c1.getLeftShoulder().setPositionRelativeToVehicle(new Position(-4.08E-17, 1.94E-16, -0.0772));
        this.c1.getLeftElbow().setPositionRelativeToVehicle(new Position(1.94E-16, 9.24E-14, -0.164));
        this.c1.getLeftWrist().setPositionRelativeToVehicle(new Position(2.0E-16, 8.79E-14, -0.155));
        this.c1.getLeftHand().setPositionRelativeToVehicle(new Position(7.87E-17, 1.94E-16, -0.0369));
        this.c1.getLeftThumb().setPositionRelativeToVehicle(new Position(-1.94E-16, -2.9E-16, -0.0292));
        this.c1.getLeftThumbKnuckle().setPositionRelativeToVehicle(new Position(-9.68E-17, -1.07E-14, -0.0253));
        this.c1.getLeftIndexFinger().setPositionRelativeToVehicle(new Position(-0.05, 0.00132, -0.0283));
        this.c1.getLeftIndexFingerKnuckle().setPositionRelativeToVehicle(new Position(-3.63E-17, 6.78E-16, -0.0266));
        this.c1.getLeftMiddleFinger().setPositionRelativeToVehicle(new Position(-0.0561, 0.00255, -0.0162));
        this.c1.getLeftMiddleFingerKnuckle().setPositionRelativeToVehicle(new Position(-3.03E-17, 1.74E-15, -0.0282));
        this.c1.getLeftPinkyFinger().setPositionRelativeToVehicle(new Position(-0.0536, -9.68E-16, 0.0156));
        this.c1.getLeftPinkyFingerKnuckle().setPositionRelativeToVehicle(new Position(-3.63E-17, 1.16E-15, -0.0211));
        this.d1.setRadius(0.5);
        this.d1.setPaint(Color.WHITE);
        this.d1.setOpacity(1.0);
        this.d1.setName("d1");
        this.d1.setVehicle(this);
        this.d1.setOrientationRelativeToVehicle(new Orientation(0.0, 0.0, 0.0, 1.0));
        this.d1.setPositionRelativeToVehicle(new Position(2.46, 0.01, -1.09));
        this.d1.setScale(new Scale(1.0, 1.0, 1.0));
        this.d2.setRadius(0.5);
        this.d2.setPaint(Color.WHITE);
        this.d2.setOpacity(1.0);
        this.d2.setName("d2");
        this.d2.setVehicle(this);
        this.d2.setOrientationRelativeToVehicle(new Orientation(0.0, 0.0, 0.0, 1.0));
        this.d2.setPositionRelativeToVehicle(new Position(1.24, 0.01, -1.03));
        this.d2.setScale(new Scale(1.0, 1.0, 1.0));
        this.d3.setRadius(0.5);
        this.d3.setPaint(Color.WHITE);
        this.d3.setOpacity(1.0);
        this.d3.setName("d3");
        this.d3.setVehicle(this);
        this.d3.setOrientationRelativeToVehicle(new Orientation(0.0, 0.0, 0.0, 1.0));
        this.d3.setPositionRelativeToVehicle(new Position(-0.119, 0.01, -1.38));
        this.d3.setScale(new Scale(1.0, 1.0, 1.0));
        this.d4.setRadius(0.5);
        this.d4.setPaint(Color.WHITE);
        this.d4.setOpacity(1.0);
        this.d4.setName("d4");
        this.d4.setVehicle(this);
        this.d4.setOrientationRelativeToVehicle(new Orientation(0.0, 0.0, 0.0, 1.0));
        this.d4.setPositionRelativeToVehicle(new Position(-1.38, 0.01, -1.06));
        this.d4.setScale(new Scale(1.0, 1.0, 1.0));
        this.d5.setRadius(0.5);
        this.d5.setPaint(Color.WHITE);
        this.d5.setOpacity(1.0);
        this.d5.setName("d5");
        this.d5.setVehicle(this);
        this.d5.setOrientationRelativeToVehicle(new Orientation(0.0, 0.0, 0.0, 1.0));
        this.d5.setPositionRelativeToVehicle(new Position(-2.53, 0.01, -1.15));
        this.d5.setScale(new Scale(1.0, 1.0, 1.0));
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="/* Procedures and functions to handle multiple scenes */">
    @Override
    protected void handleActiveChanged(Boolean isActive, Integer activationCount) {
        if (isActive) {
            if (activationCount == 1) {
                this.performGeneratedSetUp();
                this.performCustomSetup();
                this.initializeEventListeners();
            } else {
                this.restoreStateAndEventListeners();
            }
        } else {
            this.preserveStateAndEventListeners();
        }
    }

    public SGround getGround() {
        return this.ground;
    }

    public SCamera getCamera() {
        return this.camera;
    }

    public PlayingCard getC7() {
        return this.c7;
    }

    public PlayingCard getC5() {
        return this.c5;
    }

    public PlayingCard getC4() {
        return this.c4;
    }

    public PlayingCard getC9() {
        return this.c9;
    }

    public PlayingCard getC1() {
        return this.c1;
    }

    public Disc getD1() {
        return this.d1;
    }

    public Disc getD2() {
        return this.d2;
    }

    public Disc getD3() {
        return this.d3;
    }

    public Disc getD4() {
        return this.d4;
    }

    public Disc getD5() {
        return this.d5;
    }
    // </editor-fold>
}
