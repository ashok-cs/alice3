// <editor-fold defaultstate="collapsed" desc="imports">

import org.lgna.story.*;
// </editor-fold>

class Disc extends SDisc {

    /* Construct new Disc */
    public Disc() {
        super();
    }
}
