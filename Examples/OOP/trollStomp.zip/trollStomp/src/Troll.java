// <editor-fold defaultstate="collapsed" desc="imports">

import org.lgna.story.*;
import org.lgna.story.resources.biped.TrollResource;
import static org.lgna.common.ThreadUtilities.doTogether;
// </editor-fold>

class Troll extends Biped {

    /* Construct new Troll */
    public Troll() {
        super(TrollResource.DEFAULT);
    }

    public void stomp() {
        doTogether(() -> {
            this.getRightHip().turn(TurnDirection.BACKWARD, 0.25);
        }, () -> {
            this.getRightKnee().turn(TurnDirection.FORWARD, 0.25);
        });
        doTogether(() -> {
            this.getRightHip().turn(TurnDirection.FORWARD, 0.25);
        }, () -> {
            this.getRightKnee().turn(TurnDirection.BACKWARD, 0.25);
        });
    }
}
