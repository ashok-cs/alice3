// <editor-fold defaultstate="collapsed" desc="imports">

import org.lgna.story.*;
import org.lgna.story.resources.biped.TortoiseResource;
// </editor-fold>

class Tortoise extends Biped {

    /* Construct new Tortoise */
    public Tortoise() {
        super(TortoiseResource.DEFAULT);
    }

}
