// <editor-fold defaultstate="collapsed" desc="imports">

import org.lgna.story.TurnDirection;
import org.lgna.story.resources.biped.YetiBabyResource;
// </editor-fold>

class YetiBaby extends Biped {

    /* Construct new YetiBaby */
    public YetiBaby(YetiBabyResource resource) {
        super(resource);
    }

    public void setYetiBabyResource(YetiBabyResource yetiBabyResource) {
        this.setJointedModelResource(yetiBabyResource);
    }
    
    @Override
    public void turnAround(){
        this.turn(TurnDirection.LEFT, 1.0);
        this.turn(TurnDirection.LEFT, 1.0);
        this.turn(TurnDirection.LEFT, 1.0);
        this.turn(TurnDirection.LEFT, 1.0);
        this.turn(TurnDirection.LEFT, 1.0);
    
    }
}
