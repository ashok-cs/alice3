// <editor-fold defaultstate="collapsed" desc="imports">

import org.lgna.story.*;
import org.lgna.story.resources.PropResource;
// </editor-fold>

class Prop extends SProp {

    /* Construct new Prop */
    public Prop(PropResource resource) {
        super(resource);
    }
}
