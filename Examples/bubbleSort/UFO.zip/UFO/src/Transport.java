// <editor-fold defaultstate="collapsed" desc="imports">

import org.lgna.story.*;
import org.lgna.story.resources.TransportResource;
// </editor-fold>

class Transport extends STransport {

    /* Construct new Transport */
    public Transport(TransportResource resource) {
        super(resource);
    }
}
