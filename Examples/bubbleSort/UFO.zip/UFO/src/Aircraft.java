// <editor-fold defaultstate="collapsed" desc="imports">

import org.lgna.story.resources.AircraftResource;
// </editor-fold>

class Aircraft extends Transport {

    /* Construct new Aircraft */
    public Aircraft(AircraftResource resource) {
        super(resource);
    }
}
