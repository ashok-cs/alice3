// <editor-fold defaultstate="collapsed" desc="imports">

import org.lgna.story.resources.biped.AlienResource;
// </editor-fold>

class Alien extends Biped {

    /* Construct new Alien */
    public Alien() {
        super(AlienResource.DEFAULT);
    }
}
