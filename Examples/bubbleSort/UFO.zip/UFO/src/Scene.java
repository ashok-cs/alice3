// <editor-fold defaultstate="collapsed" desc="imports">

import org.lgna.story.*;
import org.lgna.story.event.SceneActivationEvent;
import org.lgna.story.resources.prop.PlateauResource;
import org.lgna.story.resources.prop.BoulderResource;
import org.lgna.story.SGround.SurfaceAppearance;
import javax.swing.JOptionPane;
import java.text.DecimalFormat;
// </editor-fold>

class Scene extends SScene {

    /* Construct new Scene */
    public Scene() {
        super();
    }

    /* Event listeners */
    private void initializeEventListeners() {
        this.addSceneActivationListener((SceneActivationEvent event) -> {
            this.myFirstMethod();
        });
    }

    /* Procedures and functions for this scene */
    public void myFirstMethod() {    
        
        alien.delay(2);
        alien.say("Measuring circumference");
        DecimalFormat DF=new DecimalFormat("0.00");
        alien.say("UFO 1: "+DF.format(uFO.getCircumference()));
        alien.delay(1);
        alien.say("UFO 2: "+DF.format(uFO2.getCircumference()));
        alien.delay(1);
        alien.say("UFO 3: "+DF.format(uFO3.getCircumference()));
        alien.delay(1);
        String input=JOptionPane.showInputDialog(null,"Enter width for UFO");
        double ufo1width=Double.parseDouble(input);
        uFO.setWidth(ufo1width);
        alien.delay(1);
        alien.say("Modified UFO 1: "+DF.format(uFO.getCircumference()));
        
    }
    /* End procedures and functions for this scene */

    // <editor-fold defaultstate="collapsed" desc="/* Scene fields  */">
    private final SGround ground = new SGround();
    private final SCamera camera = new SCamera();
    private final Alien alien = new Alien();
    private final Boulder boulder = new Boulder(BoulderResource.BOULDER1_BROWN);
    private final Boulder boulder2 = new Boulder(BoulderResource.BOULDER2_BROWN);
    private final Plateau plateau = new Plateau(PlateauResource.TALL_BROWN);
    private final UFO uFO = new UFO();
    private final UFO uFO2 = new UFO();
    private final UFO uFO3 = new UFO();
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="/* Scene setup  */">
    private void performCustomSetup() {
//Make adjustments to the starting scene, in a way not available in the Scene editor
    }

    private void performGeneratedSetUp() {
//DO NOT EDIT
//This code is automatically generated.  Any work you perform in this method will be overwritten.
//DO NOT EDIT
        this.setAtmosphereColor(new Color(0.886, 0.831, 0.51));
        this.setFromAboveLightColor(Color.WHITE);
        this.setFromBelowLightColor(new Color(0.322, 0.0745, 0.0));
        this.setFogDensity(0.2);
        this.setName("myScene");
        this.ground.setPaint(SurfaceAppearance.SANDY_DESERT);
        this.ground.setOpacity(1.0);
        this.ground.setName("ground");
        this.ground.setVehicle(this);
        this.camera.setName("camera");
        this.camera.setVehicle(this);
        this.camera.setOrientationRelativeToVehicle(new Orientation(0.0, 0.995185, 0.0980144, 6.12323E-17));
        this.camera.setPositionRelativeToVehicle(new Position(9.61E-16, 1.56, -7.85));
        this.alien.setPaint(Color.WHITE);
        this.alien.setOpacity(1.0);
        this.alien.setName("alien");
        this.alien.setVehicle(this);
        this.alien.setOrientationRelativeToVehicle(new Orientation(0.0, 0.0, 0.0, 1.0));
        this.alien.setPositionRelativeToVehicle(new Position(-0.0266, 0.0, -1.35));
        this.alien.setScale(new Scale(1.0, 1.0, 1.0));
        this.boulder.setPaint(Color.WHITE);
        this.boulder.setOpacity(1.0);
        this.boulder.setName("boulder");
        this.boulder.setVehicle(this);
        this.boulder.setOrientationRelativeToVehicle(new Orientation(0.0, 0.0, 0.0, 1.0));
        this.boulder.setPositionRelativeToVehicle(new Position(0.929, 0.0, -2.84));
        this.boulder.setScale(new Scale(1.0, 1.0, 1.0));
        this.boulder2.setPaint(Color.WHITE);
        this.boulder2.setOpacity(1.0);
        this.boulder2.setName("boulder2");
        this.boulder2.setVehicle(this);
        this.boulder2.setOrientationRelativeToVehicle(new Orientation(0.0, 0.0, 0.0, 1.0));
        this.boulder2.setPositionRelativeToVehicle(new Position(-1.4, 0.0, 0.785));
        this.boulder2.setScale(new Scale(1.0, 1.0, 1.0));
        this.plateau.setPaint(Color.WHITE);
        this.plateau.setOpacity(1.0);
        this.plateau.setName("plateau");
        this.plateau.setVehicle(this);
        this.plateau.setOrientationRelativeToVehicle(new Orientation(0.0, 0.0, 0.0, 1.0));
        this.plateau.setPositionRelativeToVehicle(new Position(-1.75, 0.0, -3.6));
        this.plateau.setScale(new Scale(1.0, 1.0, 1.0));
        this.uFO.setPaint(Color.WHITE);
        this.uFO.setOpacity(1.0);
        this.uFO.setName("uFO");
        this.uFO.setVehicle(this);
        this.uFO.setOrientationRelativeToVehicle(new Orientation(0.0, 0.0, 0.0, 1.0));
        this.uFO.setPositionRelativeToVehicle(new Position(5.58, 0.0, 8.33));
        this.uFO.setScale(new Scale(1.0, 1.0, 1.0));
        this.uFO2.setPaint(Color.WHITE);
        this.uFO2.setOpacity(1.0);
        this.uFO2.setName("uFO2");
        this.uFO2.setVehicle(this);
        this.uFO2.setOrientationRelativeToVehicle(new Orientation(0.0, 0.0, 0.0, 1.0));
        this.uFO2.setPositionRelativeToVehicle(new Position(-0.131, 0.0, 30.0));
        this.uFO2.setScale(new Scale(1.0, 1.0, 1.0));
        this.uFO3.setPaint(Color.WHITE);
        this.uFO3.setOpacity(1.0);
        this.uFO3.setName("uFO3");
        this.uFO3.setVehicle(this);
        this.uFO3.setOrientationRelativeToVehicle(new Orientation(0.0, 0.0, 0.0, 1.0));
        this.uFO3.setPositionRelativeToVehicle(new Position(-7.0, 0.0, 20.0));
        this.uFO3.setScale(new Scale(1.0, 1.0, 1.0));
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="/* Procedures and functions to handle multiple scenes */">
    @Override
    protected void handleActiveChanged(Boolean isActive, Integer activationCount) {
        if (isActive) {
            if (activationCount == 1) {
                this.performGeneratedSetUp();
                this.performCustomSetup();
                this.initializeEventListeners();
            } else {
                this.restoreStateAndEventListeners();
            }
        } else {
            this.preserveStateAndEventListeners();
        }
    }

    public SGround getGround() {
        return this.ground;
    }

    public SCamera getCamera() {
        return this.camera;
    }

    public Alien getAlien() {
        return this.alien;
    }

    public Boulder getBoulder() {
        return this.boulder;
    }

    public Boulder getBoulder2() {
        return this.boulder2;
    }

    public Plateau getPlateau() {
        return this.plateau;
    }

    public UFO getUFO() {
        return this.uFO;
    }

    public UFO getUFO2() {
        return this.uFO2;
    }

    public UFO getUFO3() {
        return this.uFO3;
    }
    // </editor-fold>
}
