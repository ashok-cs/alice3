// <editor-fold defaultstate="collapsed" desc="imports">

import org.lgna.story.resources.quadruped.ScottyDogResource;
// </editor-fold>

class ScottyDog extends Quadruped {
    String gender;
    /* Construct new dog */
    public ScottyDog() {
        super(ScottyDogResource.DEFAULT);
        gender="Unknown";
    }
    public ScottyDog(String x) {
        super(ScottyDogResource.DEFAULT);
        gender=x;
    }
    public void speak(){
        this.say("ARF! ARF! I am "+gender);
    
    }
}
