// <editor-fold defaultstate="collapsed" desc="imports">

import org.lgna.story.resources.quadruped.AbyssinianCatResource;
import org.lgna.story.*;
// </editor-fold>

class AbyssinianCat extends Quadruped {

    /* Construct new cat */
    public AbyssinianCat() {
        super(AbyssinianCatResource.DEFAULT);
    }
    
    public void speak(){
        this.say("MEOW");
    
    }
    
    public void sleep(){
        this.roll(RollDirection.LEFT,0.25);
        this.say("zzzzzzzzzz");
    
    }
            
}
