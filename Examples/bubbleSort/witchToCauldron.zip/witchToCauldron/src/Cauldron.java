// <editor-fold defaultstate="collapsed" desc="imports">

import org.lgna.story.resources.prop.CauldronResource;
// </editor-fold>

class Cauldron extends Prop {

    /* Construct new Cauldron */
    public Cauldron() {
        super(CauldronResource.DEFAULT);
    }
}
