// <editor-fold defaultstate="collapsed" desc="imports">

import org.lgna.story.resources.biped.WitchResource;
// </editor-fold>

class Witch extends Biped {

    /* Construct new Witch */
    public Witch() {
        super(WitchResource.DEFAULT);
    }
}
