// <editor-fold defaultstate="collapsed" desc="imports">

import org.lgna.story.*;
import org.lgna.story.resources.biped.AliceResource;
import org.lgna.story.SGround.SurfaceAppearance;
import org.lgna.story.event.SceneActivationEvent;
// </editor-fold>
import static java.lang.Math.sqrt;

class Scene extends SScene {

    /* Construct new Scene */
    public Scene() {
        super();
    }

    /* Event listeners */
    private void initializeEventListeners() {
        this.addSceneActivationListener((SceneActivationEvent event) -> {
            this.myFirstMethod();
        });
    }

    /* Procedures and functions for this scene */
    public void myFirstMethod() {
        this.alice.move(MoveDirection.FORWARD, 0.25);
        this.alice.getSpineBase().turn(TurnDirection.FORWARD, 0.125);
        this.alice.getSpineBase().turn(TurnDirection.BACKWARD, 0.125);
        int N=this.alice.getIntegerFromUser("Enter Upper Limit N");
        int c;
        int c_square;
        String sides;
        this.alice.say("The possible right angle triangles are");
        for(int i=1;i<=N;i++){
            for(int j=i;j<N;j++){
                c_square=i*i+j*j;
                c=(int)sqrt(c_square);                
                if(c*c==c_square){
                    sides=i+" , "+j+" and "+c;
                    this.alice.say("Triangle with sides "+sides+
                    " is the right angle triangle" );                    
                }
            }
        
        }
    }
    /* End procedures and functions for this scene */

    // <editor-fold defaultstate="collapsed" desc="/* Scene fields  */">
    private final SGround ground = new SGround();
    private final SCamera camera = new SCamera();
    private final Alice alice = new Alice(AliceResource.WONDERLAND);
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="/* Scene setup  */">
    private void performCustomSetup() {
//Make adjustments to the starting scene, in a way not available in the Scene editor
    }

    private void performGeneratedSetUp() {
//DO NOT EDIT
//This code is automatically generated.  Any work you perform in this method will be overwritten.
//DO NOT EDIT
        this.setAtmosphereColor(new Color(0.588, 0.886, 0.988));
        this.setFromAboveLightColor(Color.WHITE);
        this.setFromBelowLightColor(Color.BLACK);
        this.setFogDensity(0.0);
        this.setName("myScene");
        this.ground.setPaint(SurfaceAppearance.GRASS);
        this.ground.setOpacity(1.0);
        this.ground.setName("ground");
        this.ground.setVehicle(this);
        this.camera.setName("camera");
        this.camera.setVehicle(this);
        this.camera.setOrientationRelativeToVehicle(new Orientation(0.0, 0.995185, 0.0980144, 6.12323E-17));
        this.camera.setPositionRelativeToVehicle(new Position(9.61E-16, 1.56, -7.85));
        this.alice.setPaint(Color.WHITE);
        this.alice.setOpacity(1.0);
        this.alice.setName("alice");
        this.alice.setVehicle(this);
        this.alice.setOrientationRelativeToVehicle(new Orientation(0.0, 0.0, 0.0, 1.0));
        this.alice.setPositionRelativeToVehicle(new Position(0.258, 0.0, -2.41));
        this.alice.setScale(new Scale(1.0, 1.0, 1.0));
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="/* Procedures and functions to handle multiple scenes */">
    @Override
    protected void handleActiveChanged(Boolean isActive, Integer activationCount) {
        if (isActive) {
            if (activationCount == 1) {
                this.performGeneratedSetUp();
                this.performCustomSetup();
                this.initializeEventListeners();
            } else {
                this.restoreStateAndEventListeners();
            }
        } else {
            this.preserveStateAndEventListeners();
        }
    }

    public SGround getGround() {
        return this.ground;
    }

    public SCamera getCamera() {
        return this.camera;
    }

    public Alice getAlice() {
        return this.alice;
    }
    // </editor-fold>
}
