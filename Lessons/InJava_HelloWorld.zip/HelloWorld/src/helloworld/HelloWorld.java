/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helloworld;
import javax.swing.JOptionPane;
/**
 *
 * @author ashok
 */
public class HelloWorld {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String name=JOptionPane.showInputDialog("What's your name?");
        JOptionPane.showMessageDialog(null, "Hello "+name);
        Person p1=new Person(name, 38);
        int dogAge=0;
        JOptionPane.showMessageDialog(null, "Your age is "+p1.getAge());
        
        /*  A one year old dog roughly corresponds to a fourteen year old 
         *  A dog who is two years old corresponds to a 22 year old human
         *  Every further dog year corresponds to five human years 
        */
        
        if(p1.getAge()<= 14)
            dogAge=1;
        else if (p1.getAge()<= 22)
            dogAge=2;
        else
            dogAge=(p1.getAge()-22)/5 + 2;
        JOptionPane.showMessageDialog(null,"Your dog Age is "+dogAge);
        
        
    }
    
}
