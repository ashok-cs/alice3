// <editor-fold defaultstate="collapsed" desc="imports">

import org.lgna.story.*;
import org.lgna.story.resources.BipedResource;
// </editor-fold>

class Biped extends SBiped {

    /* Construct new Biped */
    public Biped(BipedResource resource) {
        super(resource);
    }
}
