// <editor-fold defaultstate="collapsed" desc="imports">

import org.lgna.story.*;
import org.lgna.story.resources.quadruped.DalmatianResource;
// </editor-fold>

class Dalmatian extends Quadruped {

    /* Construct new Dalmatian */
    public Dalmatian() {
        super(DalmatianResource.DEFAULT);
    }

    public void wag(Double duration) {
        this.getTail().turn(TurnDirection.LEFT, 0.125, Turn.duration(duration));
        this.getTail().turn(TurnDirection.RIGHT, 0.25, Turn.duration(duration));
        this.getTail().turn(TurnDirection.LEFT, 0.125, Turn.duration(duration));
    
    }

    public SJoint getLeftEarMiddle() {
        return this.getJoint(DalmatianResource.LEFT_EAR_MIDDLE);
    }

    public SJoint getRightEarMiddle() {
        return this.getJoint(DalmatianResource.RIGHT_EAR_MIDDLE);
    }
}
