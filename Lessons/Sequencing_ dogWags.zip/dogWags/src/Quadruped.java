// <editor-fold defaultstate="collapsed" desc="imports">

import org.lgna.story.*;
import org.lgna.story.resources.QuadrupedResource;
// </editor-fold>

class Quadruped extends SQuadruped {

    /* Construct new Quadruped */
    public Quadruped(QuadrupedResource resource) {
        super(resource);
    }
}
