// <editor-fold defaultstate="collapsed" desc="imports">

import org.lgna.story.*;
import org.lgna.story.event.SceneActivationEvent;
import org.lgna.story.SGround.SurfaceAppearance;
// </editor-fold>

class Scene extends SScene {

    /* Construct new Scene */
    public Scene() {
        super();
    }

    /* Event listeners */
    private void initializeEventListeners() {
        this.addSceneActivationListener((SceneActivationEvent event) -> {
            this.myFirstMethod();
        });
    }

    /* Procedures and functions for this scene */
    public void myFirstMethod() {
        this.delay(2);
        this.john.wag(0.25);
        this.spike.wag(0.5);
    }
    /* End procedures and functions for this scene */

    // <editor-fold defaultstate="collapsed" desc="/* Scene fields  */">
    private final SGround ground = new SGround();
    private final SCamera camera = new SCamera();
    private final Dalmatian john = new Dalmatian();
    private final Dalmatian spike = new Dalmatian();
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="/* Scene setup  */">
    private void performCustomSetup() {
//Make adjustments to the starting scene, in a way not available in the Scene editor
    }

    private void performGeneratedSetUp() {
//DO NOT EDIT
//This code is automatically generated.  Any work you perform in this method will be overwritten.
//DO NOT EDIT
        this.setAtmosphereColor(new Color(0.0, 0.0941, 0.294));
        this.setFromAboveLightColor(Color.WHITE);
        this.setFromBelowLightColor(new Color(0.541, 0.0, 0.125));
        this.setFogDensity(0.1);
        this.setName("myScene");
        this.ground.setPaint(SurfaceAppearance.DARK_GRASS);
        this.ground.setOpacity(1.0);
        this.ground.setName("ground");
        this.ground.setVehicle(this);
        this.camera.setName("camera");
        this.camera.setVehicle(this);
        this.camera.setOrientationRelativeToVehicle(new Orientation(0.0, 0.995185, 0.0980144, 6.12323E-17));
        this.camera.setPositionRelativeToVehicle(new Position(9.61E-16, 1.56, -7.85));
        this.john.setPaint(Color.WHITE);
        this.john.setOpacity(1.0);
        this.john.setName("john");
        this.john.setVehicle(this);
        this.john.setOrientationRelativeToVehicle(new Orientation(0.0, 0.0, 0.0, 1.0));
        this.john.setPositionRelativeToVehicle(new Position(1.19, 0.0, -2.35));
        this.john.setScale(new Scale(1.0, 1.0, 1.0));
        this.spike.setPaint(Color.WHITE);
        this.spike.setOpacity(1.0);
        this.spike.setName("spike");
        this.spike.setVehicle(this);
        this.spike.setOrientationRelativeToVehicle(new Orientation(0.0, 0.0, 0.0, 1.0));
        this.spike.setPositionRelativeToVehicle(new Position(-0.866, 0.0, -2.51));
        this.spike.setScale(new Scale(1.71, 1.71, 1.71));
        this.spike.getSpineMiddle().setPositionRelativeToVehicle(new Position(-3.07E-15, -3.65E-16, -0.363));
        this.spike.getSpineUpper().setPositionRelativeToVehicle(new Position(-3.16E-17, 3.65E-16, -0.407));
        this.spike.getNeck().setPositionRelativeToVehicle(new Position(3.33E-18, -2.43E-16, -0.233));
        this.spike.getHead().setPositionRelativeToVehicle(new Position(3.63E-17, 6.38E-16, -0.399));
        this.spike.getLeftEye().setPositionRelativeToVehicle(new Position(-0.0611, 0.0761, -0.0907));
        this.spike.getLeftEyelid().setPositionRelativeToVehicle(new Position(-0.0611, 0.0761, -0.0907));
        this.spike.getLeftEar().setPositionRelativeToVehicle(new Position(-0.126, 0.103, 0.0486));
        this.spike.getMouth().setPositionRelativeToVehicle(new Position(7.71E-4, -0.0419, -0.033));
        this.spike.getRightEar().setPositionRelativeToVehicle(new Position(0.126, 0.103, 0.0486));
        this.spike.getRightEye().setPositionRelativeToVehicle(new Position(0.0611, 0.0761, -0.0907));
        this.spike.getRightEyelid().setPositionRelativeToVehicle(new Position(0.0611, 0.0761, -0.0907));
        this.spike.getFrontLeftClavicle().setPositionRelativeToVehicle(new Position(-0.122, -0.194, -0.0327));
        this.spike.getFrontLeftShoulder().setPositionRelativeToVehicle(new Position(2.33E-15, 4.26E-16, -0.23));
        this.spike.getFrontLeftKnee().setPositionRelativeToVehicle(new Position(1.22E-15, -3.04E-16, -0.433));
        this.spike.getFrontLeftAnkle().setPositionRelativeToVehicle(new Position(2.93E-15, 0.0, -0.143));
        this.spike.getFrontLeftFoot().setPositionRelativeToVehicle(new Position(2.22E-15, -2.43E-16, -0.0803));
        this.spike.getFrontLeftToe().setPositionRelativeToVehicle(new Position(-4.86E-16, 1.66E-17, -0.0498));
        this.spike.getFrontRightClavicle().setPositionRelativeToVehicle(new Position(0.122, -0.194, -0.0328));
        this.spike.getFrontRightShoulder().setPositionRelativeToVehicle(new Position(2.5E-14, -1.22E-16, -0.23));
        this.spike.getFrontRightKnee().setPositionRelativeToVehicle(new Position(3.2E-14, -1.52E-16, -0.433));
        this.spike.getFrontRightAnkle().setPositionRelativeToVehicle(new Position(-1.26E-14, -1.82E-16, -0.143));
        this.spike.getFrontRightFoot().setPositionRelativeToVehicle(new Position(-1.16E-14, 1.22E-16, -0.0803));
        this.spike.getFrontRightToe().setPositionRelativeToVehicle(new Position(-4.62E-15, -4.04E-17, -0.0498));
        this.spike.getTail().setPositionRelativeToVehicle(new Position(-1.89E-16, 3.65E-16, -0.191));
        this.spike.getBackLeftHip().setPositionRelativeToVehicle(new Position(0.17, -0.128, -0.0706));
        this.spike.getBackLeftKnee().setPositionRelativeToVehicle(new Position(-4.47E-15, -2.43E-16, -0.313));
        this.spike.getBackLeftHock().setPositionRelativeToVehicle(new Position(6.08E-17, -1.22E-16, -0.311));
        this.spike.getBackLeftAnkle().setPositionRelativeToVehicle(new Position(-6.08E-17, 1.22E-16, -0.137));
        this.spike.getBackLeftFoot().setPositionRelativeToVehicle(new Position(3.04E-16, 1.22E-16, -0.0971));
        this.spike.getBackLeftToe().setPositionRelativeToVehicle(new Position(3.04E-17, -6.89E-17, -0.0368));
        this.spike.getBackRightHip().setPositionRelativeToVehicle(new Position(-0.171, -0.128, -0.0696));
        this.spike.getBackRightKnee().setPositionRelativeToVehicle(new Position(-3.77E-15, 2.43E-16, -0.313));
        this.spike.getBackRightHock().setPositionRelativeToVehicle(new Position(-3.1E-15, 2.43E-16, -0.311));
        this.spike.getBackRightAnkle().setPositionRelativeToVehicle(new Position(-3.22E-15, 2.43E-16, -0.137));
        this.spike.getBackRightFoot().setPositionRelativeToVehicle(new Position(-2.4E-15, -4.86E-16, -0.0971));
        this.spike.getBackRightToe().setPositionRelativeToVehicle(new Position(-3.65E-16, 2.81E-16, -0.0368));
        this.spike.getLeftEarMiddle().setPositionRelativeToVehicle(new Position(-1.22E-16, -9.24E-15, -0.0972));
        this.spike.getRightEarMiddle().setPositionRelativeToVehicle(new Position(1.22E-16, 7.05E-15, -0.0972));
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="/* Procedures and functions to handle multiple scenes */">
    @Override
    protected void handleActiveChanged(Boolean isActive, Integer activationCount) {
        if (isActive) {
            if (activationCount == 1) {
                this.performGeneratedSetUp();
                this.performCustomSetup();
                this.initializeEventListeners();
            } else {
                this.restoreStateAndEventListeners();
            }
        } else {
            this.preserveStateAndEventListeners();
        }
    }

    public SGround getGround() {
        return this.ground;
    }

    public SCamera getCamera() {
        return this.camera;
    }

    public Dalmatian getJohn() {
        return this.john;
    }

    public Dalmatian getSpike() {
        return this.spike;
    }
    // </editor-fold>
}
